#pragma once
#include "stdafx.h"

DWORD WINAPI KillAds (LPVOID);
DWORD WINAPI KillBanner (LPVOID);
DWORD WINAPI Developer (LPVOID);
